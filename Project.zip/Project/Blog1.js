document.addEventListener('DOMContentLoaded', () => {
    const postForm = document.getElementById('post-form');
    const postTitle = document.getElementById('post-title');
    const postContent = document.getElementById('post-content');
    const posts = document.getElementById('posts');
    let isEditing = false;
    let editingPost = null;

    // Function to add a new post
    const addPost = (title, content) => {
        const post = document.createElement('article');
        post.classList.add('post');

        const postTitleElement = document.createElement('h2');
        postTitleElement.innerText = title;

        const postContentElement = document.createElement('p');
        postContentElement.innerText = content;

        const editButton = document.createElement('button');
        editButton.innerText = 'Edit';
        editButton.classList.add('edit-button');
        editButton.addEventListener('click', () => {
            isEditing = true;
            editingPost = post;
            postTitle.value = title;
            postContent.value = content;
        });

        const deleteButton = document.createElement('button');
        deleteButton.innerText = 'Delete';
        deleteButton.classList.add('delete-button');
        deleteButton.addEventListener('click', () => {
            posts.removeChild(post);
        });

        post.appendChild(postTitleElement);
        post.appendChild(postContentElement);
        post.appendChild(editButton);
        post.appendChild(deleteButton);
        posts.appendChild(post);
    };

    // Event listener for form submission
    postForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const title = postTitle.value.trim();
        const content = postContent.value.trim();

        if (title && content) {
            if (isEditing) {
                editingPost.querySelector('h2').innerText = title;
                editingPost.querySelector('p').innerText = content;
                isEditing = false;
                editingPost = null;
            } else {
                addPost(title, content);
            }
            postTitle.value = '';
            postContent.value = '';
        }
    });

    // Add delete and edit functionality to initial posts
    document.querySelectorAll('.post').forEach(post => {
        const editButton = post.querySelector('.edit-button');
        const deleteButton = post.querySelector('.delete-button');

        editButton.addEventListener('click', () => {
            isEditing = true;
            editingPost = post;
            postTitle.value = post.querySelector('h2').innerText;
            postContent.value = post.querySelector('p').innerText;
        });

        deleteButton.addEventListener('click', () => {
            posts.removeChild(post);
        });
    });
});
